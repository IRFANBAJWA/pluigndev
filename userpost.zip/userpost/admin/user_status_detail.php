<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class user_status_detail{
    
    private static $instance;

	/**
	 * Returns the main instance.
	 *
	 * @return user_status_detail
	 */
	public static function instance() {
		if ( !isset( self::$instance ) ) {
			self::$instance = new user_status_detail();
					}
		return self::$instance;
	}
        //user status
        public function get_user_status( $user_id ) {
		$user_status = get_user_meta( $user_id, 'up_user_status', true );

		if ( empty( $user_status ) ) {
			$user_status = 'approved';
		}

		return $user_status;
	}
    
        }//class end
            function user_status_detail() {
                    return user_status_detail::instance();
            }

user_status_detail();
