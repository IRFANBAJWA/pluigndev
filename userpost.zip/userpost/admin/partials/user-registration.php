<?php 
get_header(); ?>
    <div class="wrap">
        <form id="login" class="ajax-auth" action="login" method="post">
    <h3>New to site? <a id="pop_signup" href="">Create an Account</a></h3>
    <hr />
    <h1>Login</h1>
    <p class="status"></p>  
    <?php wp_nonce_field('ajax-login-nonce', 'security'); ?>  
    <label for="username">Username</label>
    <input id="username" type="text" class="required" name="username">
    <label for="password">Password</label>
    <input id="password" type="password" class="required" name="password">
    <a class="text-link" href="<?php
echo wp_lostpassword_url(); ?>">Lost password?</a>
    <input class="submit_button" type="submit" value="LOGIN">
	<a class="close" href="">(close)</a>    
</form>
        <form id="register" class="ajax-auth"  action="register" method="post">
                <h3>Already have an account? <a id="pop_login"  href="">Login</a></h3>
            <hr />
            <h1>Signup</h1>
            <p class="status"></p>
            <?php wp_nonce_field('ajax-register-nonce', 'signonsecurity'); ?>         
            <label for="signonname">Username</label>
            <input id="signonname" type="text" name="signonname" class="required">
            <label for="email">Email</label>
            <input id="email" type="text" class="required email" name="email">
            <label for="signonpassword">Password</label>
            <input id="signonpassword" type="password" class="required" name="signonpassword" >
            <label for="password2">Confirm Password</label>
            <input type="password" id="password2" class="required" name="password2">
            <input class="submit_button" type="submit" value="SIGNUP">
            <a class="close" href="">(close)</a>    
        </form>
    </div>

<?php
    
function ajax_register(){
    
    // First check the nonce, if it fails the function will break
    check_ajax_referer( 'ajax-register-nonce', 'security' );
	$status = 'pending';	
    // Nonce is checked, get the POST data and sign user on
    $info = array();
  	$info['user_nicename'] = $info['nickname'] = $info['display_name'] = $info['first_name'] = $info['user_login'] = sanitize_user($_POST['username']) ;
    $info['user_pass'] = sanitize_text_field($_POST['password']);
	$info['user_email'] = sanitize_email( $_POST['email']);	
        $info['role'] = 'editor';
	// Register the user
    $user_register = wp_insert_user( $info );
    update_user_meta( $user_register, 'up_user_status', $status );
 	if ( is_wp_error($user_register) ){	
            
		$error  = $user_register->get_error_codes();		
		if(in_array('empty_user_login', $error)){
		echo json_encode(array('loggedin'=>false, 'message'=>__($user_register->get_error_message('empty_user_login'))));
                }
                elseif(in_array('existing_user_login',$error)){
			echo json_encode(array('loggedin'=>false, 'message'=>__('This username is already registered.')));
                }elseif(in_array('existing_user_email',$error)){
        echo json_encode(array('loggedin'=>false, 'message'=>__('This email address is already registered.')));
                }
                
                } else {
	  auth_user_login($info['nickname'], $info['user_pass'], 'Registration');  
         
    }

    die();
}
    
 get_footer();