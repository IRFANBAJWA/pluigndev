<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       ib.me
 * @since      1.0.0
 *
 * @package    Userpost
 * @subpackage Userpost/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Userpost
 * @subpackage Userpost/admin
 * @author     ib <ib@gmail.vom>
 */
class Userpost_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Userpost_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Userpost_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/userpost-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Userpost_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Userpost_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/userpost-admin.js', array( 'jquery' ), $this->version, false );

	}
        //registration Templte
        function add_page_registration_template ($templates) {
            $templates['partials/myplugin-admin-display.php'] = 'UserResgistration';
            return $templates; 
        }
        function redirect_page_registration_template ($template) {
            if ('myplugin-admin-template.php' != basename ($template)){
            $template = WP_PLUGIN_DIR . '/userpost/admin/partials/user-registration.php';
            return $template;}  else{
            echo "error".basename ($template);
            exit();
        }
        }
         
function ajax_login(){

    // First check the nonce, if it fails the function will break
    check_ajax_referer( 'ajax-login-nonce', 'security' );

    // Nonce is checked, get the POST data and sign user on
  	// Call auth_user_login
	auth_user_login($_POST['username'], $_POST['password'], 'Login'); 
	

}
function ajax_register(){

    // First check the nonce, if it fails the function will break
    check_ajax_referer( 'ajax-register-nonce', 'security' );
		
    // Nonce is checked, get the POST data and sign user on
    $info = array();
  	$info['user_nicename'] = $info['nickname'] = $info['display_name'] = $info['first_name'] = $info['user_login'] = sanitize_user($_POST['username']) ;
    $info['user_pass'] = sanitize_text_field($_POST['password']);
	$info['user_email'] = sanitize_email( $_POST['email']);
	
	// Register the user
    $user_register = wp_insert_user( $info );
 	if ( is_wp_error($user_register) ){	
		$error  = $user_register->get_error_codes()	;
		
		if(in_array('empty_user_login', $error))
			echo json_encode(array('loggedin'=>false, 'message'=>__($user_register->get_error_message('empty_user_login'))));
		elseif(in_array('existing_user_login',$error))
			echo json_encode(array('loggedin'=>false, 'message'=>__('This username is already registered.')));
		elseif(in_array('existing_user_email',$error))
        echo json_encode(array('loggedin'=>false, 'message'=>__('This email address is already registered.')));
    } else {
	  auth_user_login($info['nickname'], $info['user_pass'], 'Registration');       
    }


}

    function auth_user_login($user_login, $password, $login)
    {
	$info = array();
    $info['user_login'] = $user_login;
    $info['user_password'] = $password;
    $info['remember'] = true;
	
	$user_signon = wp_signon( $info, false );
    if ( is_wp_error($user_signon) ){
		echo json_encode(array('loggedin'=>false, 'message'=>__('Wrong username or password.')));
    } else {
		wp_set_current_user($user_signon->ID); 
        echo json_encode(array('loggedin'=>true, 'message'=>__($login.' successful, redirecting...')));
    }
	
	
    }
    //set status by Defeutl Pendiing
    public function add_user_status( $user_id ) {
	$status = 'pending';
	// This check needs to happen when a user is created in the admin
	if ( isset( $_REQUEST['action'] ) && 'createuser' == $_REQUEST['action'] ) {
	$status = 'approved';
	}
	$status = apply_filters( 'new_user_default_status', $status, $user_id );
	update_user_meta( $user_id, 'up_user_status', $status );
	}    
    //add colum to user for status
    function kjl_modify_user_columns($columns) {
        $the_columns['up_user_status'] = __( 'Status', 'userpost' );
        $newcol = array_slice( $columns, 0, -1 );
        $newcol = array_merge( $newcol, $the_columns );
        $columns = array_merge( $newcol, array_slice( $columns, 1 ) );
        return $columns;
    }
    //set vaues to colum
    public function status_column( $val, $column_name, $user_id ) {
	switch ( $column_name ) {
            
	case 'up_user_status' :           
         $user_status = get_user_meta( $user_id, 'up_user_status', true );        
        if ( empty($user_status) ) {
            $user_status = 'approved';
        }
	$status = $user_status;        
	if ( $status == 'approved' ) {
	$status_i18n = __( 'approved', 'userpost' );
	} else if ( $status == 'denied' ) {
	$status_i18n = __( 'denied', 'userpost' );
	} else if ( $status == 'pending' ) {
	$status_i18n = __( 'pending', 'userpost' );
	}
	return $status_i18n;
	break;
	default:
	}
	return $val;
	}        
       //add approove and deny Link
        public function userpost_actions( $actions, $user ) {
                if ( $user->ID == get_current_user_id() )
			return $actions;
                    
		//$user_status = pw_new_user_approve()->get_user_status( $user->ID );
                $user_status = get_user_meta( $user->ID, 'up_user_status', true );                
		$approve_link = add_query_arg( array( 'action' => 'approve', 'user' => $user->ID ) );
               
                     
		$approve_link = remove_query_arg( array( 'new_role' ), $approve_link );
		$approve_link = wp_nonce_url( $approve_link );

		$deny_link = add_query_arg( array( 'action' => 'deny', 'user' => $user->ID ) );
		$deny_link = remove_query_arg( array( 'new_role' ), $deny_link );
		$deny_link = wp_nonce_url( $deny_link );

		$approve_action = '<a href="' . esc_url( $approve_link ) . '">' . __( 'Approve', 'userpost' ) . '</a>';
		$deny_action = '<a href="' . esc_url( $deny_link ) . '">' . __( 'Deny', 'userpost' ) . '</a>';

		if ( $user_status == 'pending' ) {
			$actions[] = $approve_action;
			$actions[] = $deny_action;
		} else if ( $user_status == 'approved' ) {
			$actions[] = $deny_action;
		} else if ( $user_status == 'denied' ) {
			$actions[] = $approve_action;
		}

		return $actions;
	}
        
        /**
	 * Update the user status if the approve or deny link was clicked.
	 *
	 * @uses load-users.php
	 */
	public function update_action() {
		if ( isset( $_GET['action'] ) && in_array( $_GET['action'], array( 'approve', 'deny' ) ) && !isset( $_GET['new_role'] ) ) {
                    
                   // check_admin_referer( 'userpost' );
                     //   die('Test page');
			$sendback = remove_query_arg( array( 'approved', 'denied', 'deleted', 'ids', 'nu-status-query-submit', 'new_role' ), wp_get_referer() );
			
                        if ( !$sendback )
				$sendback = admin_url( 'users.php' );

			$wp_list_table = _get_list_table( 'WP_Users_List_Table' );
			$pagenum = $wp_list_table->get_pagenum();
			$sendback = add_query_arg( 'paged', $pagenum, $sendback );
                            
			$status = sanitize_key( $_GET['action'] );
			$user = absint( $_GET['user'] );               
                         
                    $user_id = absint( $user );
                    if ( !$user_id ) {
                            return false;
                    }
                        //end satus update
			if ( $status == "approve" ) {
				 $sendback = add_query_arg( array( 'approved' => 1, 'ids' => $user ), $sendback );
                        $user = new WP_User( $user_id );

                            // change usermeta tag in database to denied
                            update_user_meta( $user->ID, 'up_user_status', 'approved' );         
			} else {
				$sendback = add_query_arg( array( 'denied' => 1, 'ids' => $user ), $sendback );
			
                                 $user = new WP_User( $user_id );

                            // change usermeta tag in database to denied
                            update_user_meta( $user->ID, 'up_user_status', 'denied' );
                        }
                      
			wp_redirect( $sendback );
			exit;
		}
	}
        //login rediecttion
        /**/
    function my_login_redirect( $redirect_to, $request, $user ) {
        //is there a user to check?
        if (isset($user->roles) && is_array($user->roles)) {
            //check for subscribers
            if (in_array('articelwriter', $user->roles)) {
                // redirect them to another URL, in this case, the homepage 
                $redirect_to =  home_url();
            }
        }

        return $redirect_to;
    }



    }
